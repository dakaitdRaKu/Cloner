<div align="center">
  <br />
  <p>

*A Discord Server Cloner Which Can Clone Any Discord Server In Just Few Minutes.*
- Clone Channels
- Channel Permissions
- Server Roles
- Server Name
- Server Banner / Avatar
- Server Emojis
- Server Settings 

## Installation
```js
$ run Cloner.exe 
```
## Features
```diff
+ Clone Channels
+ Channel Permissions
+ Server Roles
+ Server Name
+ Server Banner / Avatar
+ Server Emojis
+ Server Settings 
- Server Messages
- Server Members
```

# Developer
```js
- AiZeR xD..!
- mohit.4sure#0
- Discord - https://discord.gg/nukers
- YouTube - https://youtube.com/@nukersop
- GitHub - https://github.com/AxZeRxD
- Replit - https://replit.com/@AIZERHUBKL

* FOLLOW ME FOR MORE TOOLS *
```
